from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QPlainTextEdit, QMessageBox, QStackedWidget, QComboBox, QDateEdit, QDialog
from PyQt6.QtGui import QFont
import sqlite3
import sys
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class DatabaseManager:
    def __init__(self, database_name):
        self.database_name = database_name

    def create_tables(self):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     username TEXT,
                     full_name TEXT,
                     password TEXT,
                     email TEXT);''')
        c.execute('''CREATE TABLE IF NOT EXISTS expenses
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER,
                     category TEXT,
                     amount REAL,
                     date TEXT,
                     FOREIGN KEY (user_id) REFERENCES users (id));''')
        conn.commit()
        conn.close()

    def insert_user(self, username, full_name, password, email):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("INSERT INTO users (username, full_name, password, email) VALUES (?, ?, ?, ?)",
                  (username, full_name, password, email))
        conn.commit()
        conn.close()

    def get_user_by_credentials(self, username, password):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?",
                  (username, password))
        user = c.fetchone()
        conn.close()
        return user

    def insert_expense(self, user_id, category, amount, date):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("INSERT INTO expenses (user_id, category, amount, date) VALUES (?, ?, ?, ?)",
                  (user_id, category, amount, date))
        conn.commit()
        conn.close()

    def get_expenses_breakdown_by_category(self, user_id):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("SELECT category, SUM(amount) FROM expenses WHERE user_id=? GROUP BY category",
                  (user_id,))
        expenses = c.fetchall()
        conn.close()
        return expenses

    def get_expenses_for_all_users_by_month_and_year(self, month, year):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("SELECT username, category, SUM(amount)\
                   FROM expenses e\
                   JOIN users u ON e.user_id = u.id\
                   WHERE strftime('%m', date) = ? AND strftime('%Y', date) = ?\
                   GROUP BY e.category, u.id", (month, year))
        expenses = c.fetchall()
        conn.close()
        return expenses

    def get_expenses_for_all_users_by_category(self):
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("SELECT u.username, e.category, SUM(e.amount)\
                   FROM users u\
                   JOIN expenses e ON u.id = e.user_id\
                   GROUP BY e.category, u.id")
        expenses = c.fetchall()
        conn.close()
        return expenses


class UserProfileWidget(QWidget):
    def __init__(self, parent, user_id, database_manager):
        super().__init__(parent)
        self.parent = parent
        self.user_id = user_id
        self.database_manager = database_manager

        layout = QVBoxLayout()

        welcome_label = QLabel("Название вашего банка!")
        welcome_label.setFont(QFont("Arial", 16))
        layout.addWidget(welcome_label)

        category_label = QLabel("Категория:")
        self.category_input = QComboBox()
        self.category_input.addItem("Продукты")
        self.category_input.addItem("Жилье")
        self.category_input.addItem("Транспорт")
        self.category_input.addItem("Развлечения")
        self.category_input.addItem("Здоровье")

        amount_label = QLabel("Сумма:")
        self.amount_input = QLineEdit()

        date_label = QLabel("Дата:")
        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)

        add_expense_button = QPushButton("Добавить трату")
        add_expense_button.clicked.connect(self.add_expense)

        layout.addWidget(category_label)
        layout.addWidget(self.category_input)
        layout.addWidget(amount_label)
        layout.addWidget(self.amount_input)
        layout.addWidget(date_label)
        layout.addWidget(self.date_input)
        layout.addWidget(add_expense_button)

        self.expenses_breakdown_button = QPushButton(
            "Показать график расходов")
        self.expenses_breakdown_button.clicked.connect(
            self.draw_expenses_breakdown)
        layout.addWidget(self.expenses_breakdown_button)

        self.history_label = QLabel("История пополнений:")
        self.history_text = QPlainTextEdit()
        self.history_text.setReadOnly(True)

        layout.addWidget(self.history_label)
        layout.addWidget(self.history_text)

        exit_button = QPushButton("Выход")
        exit_button.clicked.connect(self.parent.set_login_widget)

        layout.addWidget(exit_button)

        self.setLayout(layout)

        self.load_expenses_history()

    def draw_expenses_breakdown(self):
        expenses_breakdown = self.database_manager.get_expenses_breakdown_by_category(
            self.user_id)
        if len(expenses_breakdown) == 0:  # Show nothing when no expenses
            return
        # Unzip the pairs of categories and amounts
        categories, amounts = zip(*expenses_breakdown)
        self.plot_dialog = PlotDialog(self, categories, amounts)
        self.plot_dialog.show()

    def add_expense(self):
        category = self.category_input.currentText()
        amount_str = self.amount_input.text()
        date = self.date_input.date().toString("yyyy-MM-dd")

        # проверка, не пустая ли строка
        if not amount_str.strip():
            self.show_message("Ошибка", "Введите сумму.")
            return

        try:
            amount = float(amount_str)
        except ValueError:  # если строка не может быть преобразована в число
            self.show_message("Ошибка", "Некорректная сумма.")
            return

        # проверка, не отрицательное ли число
        if amount <= 0:
            self.show_message(
                "Ошибка", "Сумма не может быть отрицательной или равной нулю.")
            return

        self.database_manager.insert_expense(
            self.user_id, category, amount, date)
        history_entry = f"Категория: {category}, Сумма: {amount}, Дата: {date}"
        self.update_history(history_entry)
        self.show_message("Успех", "Трата успешно добавлена!")

    def load_expenses_history(self):
        expenses = self.database_manager.get_expenses_breakdown_by_category(
            self.user_id)

        # Clear the history text field before adding new entries
        self.history_text.clear()

        history_entries = [
            f"Категория: {expense[0]}, Сумма: {expense[1]}"
            for expense in expenses
        ]

        self.update_history("\n".join(history_entries))

    def update_history(self, entry):
        existing_text = self.history_text.toPlainText()
        if existing_text:
            new_text = f"{existing_text}\n{entry}"
        else:
            new_text = entry

        self.history_text.setPlainText(new_text)

    def show_message(self, title, message):
        QMessageBox.information(self, title, message)


class PlotDialog(QDialog):
    def __init__(self, parent, categories, amounts):
        super().__init__(parent)
        self.setWindowTitle("График расходов")
        layout = QVBoxLayout()
        self.setLayout(layout)
        fig = Figure()
        ax = fig.add_subplot(1, 1, 1)
        ax.bar(categories, amounts)
        ax.set_ylabel('Сумма')
        ax.set_title('Расходы по категориям')
        self.canvas = FigureCanvas(fig)
        layout.addWidget(self.canvas)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Система учета и анализа данных о клиентах")
        self.setGeometry(100, 100, 400, 300)

        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)

        self.database_manager = DatabaseManager('banking_system.db')

        self.login_widget = LoginWidget(self)
        self.registration_widget = RegistrationWidget(self)
        self.user_profile_widget = None
        self.admin_widget = AdminWidget(self)

        self.stacked_widget.addWidget(self.login_widget)
        self.stacked_widget.addWidget(self.registration_widget)
        self.stacked_widget.addWidget(self.admin_widget)

        self.stacked_widget.setCurrentWidget(self.login_widget)

        self.expense_breakdown_button = QPushButton(
            "Показать разбивку по расходам")
        self.expense_breakdown_button.clicked.connect(
            self.show_expenses_breakdown)

    def show_registration(self):
        self.stacked_widget.setCurrentWidget(self.registration_widget)

    def show_user_profile(self, user_id):
        if self.user_profile_widget is None:
            self.user_profile_widget = UserProfileWidget(
                self, user_id, self.database_manager)
            self.stacked_widget.addWidget(self.user_profile_widget)
        else:
            self.user_profile_widget.user_id = user_id
            self.user_profile_widget.load_expenses_history()
            if hasattr(self.user_profile_widget, 'canvas'):  # Если график уже был ранее отрисован
                self.user_profile_widget.canvas.deleteLater()  # Удаляем предыдущий график
                self.user_profile_widget.canvas = None
        # когда переходим обратно в профиль, удаляем предыдущий график
        self.stacked_widget.setCurrentWidget(self.user_profile_widget)

    def set_login_widget(self):
        self.stacked_widget.setCurrentWidget(self.login_widget)

    def show_expenses_breakdown(self):
        if self.user_profile_widget is not None:
            self.user_profile_widget.draw_expense_breakdown()

    def show_admin(self):
        self.stacked_widget.setCurrentWidget(self.admin_widget)


class LoginWidget(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent

        layout = QVBoxLayout()

        login_label = QLabel("Логин:")
        self.login_input = QLineEdit()

        password_label = QLabel("Пароль:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        login_button = QPushButton("Вход")
        login_button.clicked.connect(self.login)

        register_button = QPushButton("Регистрация")
        register_button.clicked.connect(self.parent.show_registration)

        layout.addWidget(login_label)
        layout.addWidget(self.login_input)
        layout.addWidget(password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(login_button)
        layout.addWidget(register_button)

        self.setLayout(layout)

    def login(self):
        username = self.login_input.text()
        password = self.password_input.text()

        if username.lower() == "admin" and password == "admin":  # admin condition
            self.parent.show_admin()
        else:
            user = self.parent.database_manager.get_user_by_credentials(
                username, password)

            if user:
                self.parent.show_user_profile(user[0])
            else:
                self.show_message("Ошибка", "Неверный логин или пароль.")

    def show_message(self, title, message):
        QMessageBox.information(self, title, message)


class AdminWidget(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.database_manager = self.parent.database_manager

        layout = QVBoxLayout()

        histogram_button = QPushButton('Построить гистограмму по категориям')
        histogram_button.clicked.connect(self.create_histogram_for_all_users)
        layout.addWidget(histogram_button)

        self.year_input = QLineEdit()
        layout.addWidget(QLabel("Год:"))
        layout.addWidget(self.year_input)

        self.month_input = QLineEdit()
        layout.addWidget(QLabel("Месяц:"))
        layout.addWidget(self.month_input)

        expense_button_for_month_year = QPushButton(
            'Показать траты за месяц и год')
        expense_button_for_month_year.clicked.connect(
            self.show_expenses_for_month_and_year)
        layout.addWidget(expense_button_for_month_year)

        exit_button = QPushButton("Выход")
        # Подключите функцию set_login_widget к слоту clicked этой кнопки
        exit_button.clicked.connect(self.parent.set_login_widget)

        # Добавьте кнопку в ваше окно
        layout.addWidget(exit_button)

        self.setLayout(layout)

    def create_histogram_for_all_users(self):
        data = self.database_manager.get_expenses_for_all_users_by_category()
        if data:
            users, categories, amounts = zip(*data)
            self.plot_dialog = PlotDialog(self, categories, amounts)
            self.plot_dialog.show()

    def show_expenses_for_month_and_year(self):
        month = self.month_input.text()
        year = self.year_input.text()
        data = self.database_manager.get_expenses_for_all_users_by_month_and_year(
            month, year)
        if data:
            users, categories, amounts = zip(*data)
            self.plot_dialog = PlotDialog(self, categories, amounts)
            self.plot_dialog.show()
        else:
            QMessageBox.information(
                self, "Ошибка", "По вашему запросу данные отсутствуют.")


class RegistrationWidget(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent

        layout = QVBoxLayout()

        username_label = QLabel("Логин:")
        self.username_input = QLineEdit()

        fullname_label = QLabel("ФИО:")
        self.fullname_input = QLineEdit()

        password_label = QLabel("Пароль:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        email_label = QLabel("Электронная почта:")
        self.email_input = QLineEdit()

        register_button = QPushButton("Регистрация")
        register_button.clicked.connect(self.register)

        layout.addWidget(username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(fullname_label)
        layout.addWidget(self.fullname_input)
        layout.addWidget(password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(email_label)
        layout.addWidget(self.email_input)
        layout.addWidget(register_button)

        exit_button = QPushButton("Выход")
        exit_button.clicked.connect(self.parent.set_login_widget)

        layout.addWidget(exit_button)

        self.setLayout(layout)

    def register(self):
        username = self.username_input.text()
        full_name = self.fullname_input.text()
        password = self.password_input.text()
        email = self.email_input.text()

        if not username or not full_name or not password or not email:
            self.show_message("Ошибка", "Все поля должны быть заполнены.")
            return

        user = self.parent.database_manager.get_user_by_credentials(
            username, password)

        if user:
            self.show_message(
                "Ошибка", "Пользователь с таким логином и паролем уже существует.")
            return

        self.parent.database_manager.insert_user(
            username, full_name, password, email)

        self.show_message(
            "Успех", "Пользователь успешно зарегистрирован. Можно выполнить вход.")

        self.parent.set_login_widget()

    def show_message(self, title, message):
        QMessageBox.information(self, title, message)


if __name__ == '__main__':
    app = QApplication(sys.argv)

    database_manager = DatabaseManager('banking_system.db')
    database_manager.create_tables()

    window = MainWindow()
    window.show()

    sys.exit(app.exec())
